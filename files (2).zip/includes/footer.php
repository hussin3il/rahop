<footer class="bg-dark text-white text-center p-3 mt-5">
    جميع الحقوق محفوظة &copy; <?php echo date("Y"); ?>
</footer>
<a href="https://wa.me/966XXXXXXXXX" target="_blank"
   style="position:fixed;bottom:30px;right:30px;z-index:999;">
    <img src="assets/images/whatsapp-icon.png" alt="واتساب" width="60">
</a>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>