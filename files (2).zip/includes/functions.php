<?php
// فحص تسجيل الدخول للمدير
function check_admin() {
    session_start();
    if (!isset($_SESSION['admin_logged_in'])) {
        header("Location: ../login.php");
        exit();
    }
}

// الحماية من XSS
function e($string) {
    return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}
?>