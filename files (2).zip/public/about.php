<?php
require_once '../includes/config.php';
include '../includes/header.php';
$page = $pdo->query("SELECT * FROM pages WHERE slug='about'")->fetch();
?>
<div class="container my-5">
    <h2><?= e($page['title']) ?></h2>
    <p><?= nl2br(e($page['content'])) ?></p>
</div>
<?php include '../includes/footer.php'; ?>