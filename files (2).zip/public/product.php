<?php
require_once '../includes/config.php';
include '../includes/header.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$stmt = $pdo->prepare("SELECT * FROM products WHERE id=?");
$stmt->execute([$id]);
$product = $stmt->fetch();

if (!$product) {
    echo "<div class='container'><div class='alert alert-danger'>المنتج غير موجود.</div></div>";
    include '../includes/footer.php'; exit;
}
?>
<div class="container my-5">
    <div class="row">
        <div class="col-md-6">
            <img src="../uploads/<?= e($product['image']) ?>" class="img-fluid rounded" alt="<?= e($product['name']) ?>">
        </div>
        <div class="col-md-6">
            <h2><?= e($product['name']) ?></h2>
            <p><?= nl2br(e($product['description'])) ?></p>
            <p class="h4 text-success"><?= number_format($product['price'],2) ?> ر.س</p>
            <a href="https://wa.me/966XXXXXXXXX?text=أرغب في طلب المنتج: <?= urlencode($product['name'].' ('.$product['price'].' ر.س)') ?>" target="_blank" class="btn btn-success mb-3">طلب عبر واتساب</a>
        </div>
    </div>
</div>
<?php include '../includes/footer.php'; ?>