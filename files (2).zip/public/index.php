<?php
require_once '../includes/config.php';
include '../includes/header.php';

$category = isset($_GET['category']) ? $_GET['category'] : '';
$search   = isset($_GET['search']) ? $_GET['search'] : '';

$query = "SELECT * FROM products WHERE 1";
$params = [];

if ($category) {
    $query .= " AND category = ?";
    $params[] = $category;
}
if ($search) {
    $query .= " AND name LIKE ?";
    $params[] = "%" . $search . "%";
}
$query .= " ORDER BY created_at DESC";
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$products = $stmt->fetchAll();

$cats = $pdo->query("SELECT DISTINCT category FROM products WHERE category IS NOT NULL AND category != ''")->fetchAll(PDO::FETCH_COLUMN);
?>
<div class="container my-4">
    <form class="row mb-4" method="get">
        <div class="col-md-3">
            <select name="category" class="form-select">
                <option value="">كل التصنيفات</option>
                <?php foreach($cats as $cat): ?>
                    <option value="<?= e($cat) ?>" <?= $category==$cat?'selected':'' ?>><?= e($cat) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-6">
            <input type="text" name="search" class="form-control" placeholder="بحث عن منتج..." value="<?= e($search) ?>">
        </div>
        <div class="col-md-3">
            <button class="btn btn-primary w-100">بحث</button>
        </div>
    </form>
    <div class="row">
        <?php foreach($products as $product): ?>
            <div class="col-md-4 mb-4">
                <div class="card h-100">
                    <img src="../uploads/<?= e($product['image']) ?>" class="card-img-top" style="height:220px;object-fit:cover">
                    <div class="card-body">
                        <h5 class="card-title"><?= e($product['name']) ?></h5>
                        <p class="card-text text-success"><strong><?= number_format($product['price'],2) ?> ر.س</strong></p>
                        <a href="product.php?id=<?= $product['id'] ?>" class="btn btn-outline-primary w-100">تفاصيل المنتج</a>
                    </div>
                </div>
            </div>
        <?php endforeach; if(empty($products)): ?>
            <div class="alert alert-info">لا توجد منتجات حالياً.</div>
        <?php endif; ?>
    </div>
</div>
<?php include '../includes/footer.php'; ?>