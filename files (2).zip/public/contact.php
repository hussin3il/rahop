<?php
require_once '../includes/config.php';
include '../includes/header.php';
$page = $pdo->query("SELECT * FROM pages WHERE slug='contact'")->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name']; $phone = $_POST['phone']; $msg = $_POST['message'];
    $stmt = $pdo->prepare("INSERT INTO orders (name, phone, message) VALUES (?, ?, ?)");
    $stmt->execute([$name, $phone, $msg]);
    $sent = true;
}
?>
<div class="container my-5">
    <h2><?= e($page['title']) ?></h2>
    <p><?= nl2br(e($page['content'])) ?></p>
    <?php if(!empty($sent)): ?>
        <div class="alert alert-success">تم إرسال رسالتك بنجاح!</div>
    <?php endif; ?>
    <form method="post" class="row g-3">
        <div class="col-md-6">
            <label>الاسم</label>
            <input type="text" name="name" class="form-control" required>
        </div>
        <div class="col-md-6">
            <label>رقم الجوال</label>
            <input type="text" name="phone" class="form-control" required>
        </div>
        <div class="col-12">
            <label>رسالتك أو الاستفسار</label>
            <textarea name="message" class="form-control" required></textarea>
        </div>
        <div class="col-12">
            <button class="btn btn-primary">إرسال</button>
        </div>
    </form>
</div>
<?php include '../includes/footer.php'; ?>