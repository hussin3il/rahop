<?php
require_once '../../includes/config.php';
require_once '../../includes/functions.php';
check_admin();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>لوحة التحكم</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
</head>
<body>
<div class="container my-5">
    <h2>لوحة تحكم الإدارة</h2>
    <ul>
        <li><a href="products.php">إدارة المنتجات</a></li>
        <li><a href="pages.php">الصفحات الثابتة</a></li>
        <li><a href="orders.php">استفسارات/طلبات العملاء</a></li>
        <li><a href="logout.php">تسجيل الخروج</a></li>
    </ul>
</div>
</body>
</html>