<?php
require_once '../../includes/config.php';
require_once '../../includes/functions.php';
check_admin();

$orders = $pdo->query("SELECT o.*, p.name as product_name FROM orders o LEFT JOIN products p ON o.product_id = p.id ORDER BY o.created_at DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>استفسارات العملاء</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
</head>
<body>
<div class="container my-5">
    <h3>استفسارات / طلبات العملاء</h3>
    <table class="table table-bordered">
        <tr><th>الاسم</th><th>الجوال</th><th>المنتج</th><th>الرسالة</th><th>التاريخ</th></tr>
        <?php foreach($orders as $order): ?>
        <tr>
            <td><?= e($order['name']) ?></td>
            <td><?= e($order['phone']) ?></td>
            <td><?= e($order['product_name']) ?></td>
            <td><?= e($order['message']) ?></td>
            <td><?= e($order['created_at']) ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
    <a href="index.php" class="btn btn-secondary mt-3">رجوع للوحة التحكم</a>
</div>
</body>
</html>