<?php
require_once '../../includes/config.php';
require_once '../../includes/functions.php';
check_admin();

if(isset($_POST['slug'])) {
    $slug = $_POST['slug'];
    $title = $_POST['title'];
    $content = $_POST['content'];
    $stmt = $pdo->prepare("UPDATE pages SET title=?, content=? WHERE slug=?");
    $stmt->execute([$title, $content, $slug]);
    $msg = "تم تحديث الصفحة";
}
$pages = $pdo->query("SELECT * FROM pages")->fetchAll();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>الصفحات الثابتة</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
</head>
<body>
<div class="container my-5">
    <h3>إدارة الصفحات الثابتة</h3>
    <?php if(!empty($msg)): ?><div class="alert alert-success"><?= $msg ?></div><?php endif; ?>
    <?php foreach($pages as $page): ?>
        <form method="post" class="mb-4">
            <input type="hidden" name="slug" value="<?= e($page['slug']) ?>">
            <div class="mb-2"><input name="title" value="<?= e($page['title']) ?>" class="form-control"></div>
            <div class="mb-2"><textarea name="content" class="form-control" rows="4"><?= e($page['content']) ?></textarea></div>
            <button class="btn btn-primary">تحديث</button>
        </form>
    <?php endforeach; ?>
    <a href="index.php" class="btn btn-secondary mt-3">رجوع للوحة التحكم</a>
</div>
</body>
</html>