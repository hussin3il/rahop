<?php
require_once '../../includes/config.php';
require_once '../../includes/functions.php';
check_admin();

if(isset($_GET['del'])) {
    $id = (int)$_GET['del'];
    $stmt = $pdo->prepare("DELETE FROM products WHERE id=?");
    $stmt->execute([$id]);
    header("Location: products.php");
    exit;
}
if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name']; $desc = $_POST['description']; $price = (float)$_POST['price']; $cat = $_POST['category'];
    $img = '';
    if(isset($_FILES['image']) && $_FILES['image']['tmp_name']) {
        $img = uniqid().'.'.pathinfo($_FILES['image']['name'],PATHINFO_EXTENSION);
        move_uploaded_file($_FILES['image']['tmp_name'], '../../uploads/'.$img);
    }
    $stmt = $pdo->prepare("INSERT INTO products (name,description,price,category,image) VALUES (?,?,?,?,?)");
    $stmt->execute([$name,$desc,$price,$cat,$img]);
    header("Location: products.php");
    exit;
}
$products = $pdo->query("SELECT * FROM products ORDER BY id DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>منتجات الإدارة</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
</head>
<body>
<div class="container my-5">
    <h3>قائمة المنتجات</h3>
    <form method="post" enctype="multipart/form-data" class="row g-3 mb-4">
        <div class="col-md-3"><input name="name" class="form-control" placeholder="اسم المنتج" required></div>
        <div class="col-md-3"><input name="category" class="form-control" placeholder="الفئة"></div>
        <div class="col-md-2"><input name="price" type="number" step="0.01" class="form-control" placeholder="السعر" required></div>
        <div class="col-md-2"><input name="image" type="file" class="form-control" accept="image/*"></div>
        <div class="col-md-2"><button class="btn btn-success w-100">إضافة منتج</button></div>
        <div class="col-12"><textarea name="description" class="form-control" placeholder="وصف المنتج"></textarea></div>
    </form>

    <table class="table table-bordered">
        <tr><th>الصورة</th><th>الاسم</th><th>الوصف</th><th>السعر</th><th>الفئة</th><th>حذف</th></tr>
        <?php foreach($products as $prod): ?>
            <tr>
                <td><img src="../../uploads/<?= e($prod['image']) ?>" width="60"></td>
                <td><?= e($prod['name']) ?></td>
                <td><?= e(mb_substr($prod['description'],0,40)) ?>...</td>
                <td><?= $prod['price'] ?></td>
                <td><?= e($prod['category']) ?></td>
                <td><a href="?del=<?= $prod['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('تأكيد الحذف؟')">حذف</a></td>
            </tr>
        <?php endforeach; ?>
    </table>
    <a href="index.php" class="btn btn-secondary mt-3">رجوع للوحة التحكم</a>
</div>
</body>
</html>